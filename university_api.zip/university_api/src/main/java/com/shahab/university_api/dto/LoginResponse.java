package com.shahab.university_api.dto;

import lombok.Data;

@Data
public class LoginResponse {
    private String token;
}