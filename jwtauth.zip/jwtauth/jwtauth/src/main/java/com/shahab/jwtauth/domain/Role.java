package com.shahab.jwtauth.domain;

public enum Role {
    USER, ADMIN
}
