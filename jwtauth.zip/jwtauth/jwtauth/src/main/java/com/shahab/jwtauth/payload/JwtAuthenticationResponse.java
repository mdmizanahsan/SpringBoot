package com.shahab.jwtauth.payload;

public class JwtAuthenticationResponse {
}
