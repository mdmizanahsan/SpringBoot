package com.mizan.PolicyLLM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolicyLlmApplicationTests {

	@Test
	void contextLoads() {
	}

}
