package com.mizan.APIs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApIsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApIsApplication.class, args);
	}

}
